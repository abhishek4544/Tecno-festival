globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/AutVey_umPOJNWTqQyurr/_buildManifest.js",
    "static/AutVey_umPOJNWTqQyurr/_ssgManifest.js",
    "static/AutVey_umPOJNWTqQyurr/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/37q6gxrczg7p3.js",
    "static/chunks/2i51e627rllld.js",
    "static/chunks/00eh0_tw2eoa7.js",
    "static/chunks/2kd5d9pj4qx5x.js",
    "static/chunks/0fy4h0ngk1igg.js",
    "static/chunks/turbopack-3727g4n_8d_fn.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
