:HL["/_next/static/chunks/3rzhywsx--p1e.css","style"]
:HL["/_next/static/chunks/2ex9uz1-v4fl6.css","style"]
:HL["/_next/static/media/f06bf9da926bae75-s.p.2874ccu1_u7jf.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"(landing-page)","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"AutVey_umPOJNWTqQyurr"}
