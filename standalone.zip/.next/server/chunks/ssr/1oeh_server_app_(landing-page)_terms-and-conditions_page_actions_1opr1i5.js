module.exports=[89885,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28landing-page%29_terms-and-conditions_page_actions_1opr1i5.js.map