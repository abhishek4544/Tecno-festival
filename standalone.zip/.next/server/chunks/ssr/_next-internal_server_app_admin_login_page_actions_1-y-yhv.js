module.exports=[56551,a=>{"use strict";var b=a.i(38050);a.s([],96671),a.i(96671),a.s(["600d2c347175d2b1abeb093189fbfc3d2a0a11f934",()=>b.login],56551)}];

//# sourceMappingURL=_next-internal_server_app_admin_login_page_actions_1-y-yhv.js.map