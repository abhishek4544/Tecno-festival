module.exports=[66103,a=>{"use strict";var b=a.i(38050),c=a.i(16778),d=a.i(37936),e=a.i(18558),f=a.i(50287),g=a.i(9307),h=a.i(61469),i=a.i(13095);let j={SilverKite:"Silver Kite",SilverCoin:"Silver Coin"};async function k(a){await (0,g.requireAdmin)();let b=await h.sql`
    UPDATE scratch_results s
    SET verification_status = 'Confirmed'
    FROM participants p
    WHERE s.id = ${a}
      AND s.verification_status = 'Pending'
      AND p.id = s.participant_id
    RETURNING s.outcome, p.campaign_id, p.id AS participant_id, p.full_name, p.imei
  `;if(0===b.length)return{ok:!1,message:"Already resolved or not pending."};let c=b[0];return await (0,f.logAdminAction)({action:"verification.pass",summary:`Passed ${j[c.outcome]} win for ${c.full_name} (IMEI ${c.imei})`,campaignId:c.campaign_id,entityType:"participant",entityId:c.participant_id,details:{scratchResultId:a,outcome:c.outcome,imei:c.imei}}),(0,e.revalidatePath)("/admin/dashboard/imei-registry"),(0,e.revalidatePath)("/admin/dashboard/participants"),{ok:!0}}async function l(a){await (0,g.requireAdmin)();let b=await h.sql`
    UPDATE scratch_results s
    SET verification_status = 'Rejected'
    FROM participants p
    WHERE s.id = ${a}
      AND s.verification_status = 'Pending'
      AND s.outcome IN ('SilverKite', 'SilverCoin')
      AND p.id = s.participant_id
    RETURNING s.outcome, p.campaign_id, p.id AS participant_id, p.full_name, p.imei
  `;if(0===b.length)return{ok:!1,message:"Already resolved or not a pending win."};let{outcome:c,campaign_id:d,participant_id:i,full_name:k,imei:l}=b[0];return await h.sql`
    UPDATE rewards
    SET distributed = GREATEST(distributed - 1, 0)
    WHERE campaign_id = ${d} AND kind = ${c}::reward_kind
  `,await (0,f.logAdminAction)({action:"verification.fail",summary:`Failed ${j[c]} win for ${k} (IMEI ${l}); prize returned to stock`,campaignId:d,entityType:"participant",entityId:i,details:{scratchResultId:a,outcome:c,imei:l}}),(0,e.revalidatePath)("/admin/dashboard/imei-registry"),(0,e.revalidatePath)("/admin/dashboard/participants"),{ok:!0}}(0,i.ensureServerEntryExports)([k,l]),(0,d.registerServerReference)(k,"40d7fe121f91fa1d05e2be12c62d3438dead002b8a",null),(0,d.registerServerReference)(l,"40c469aff0537f184c28e86574382e7b947c5966e0",null),a.s([],45928),a.i(45928),a.s(["0081fcc9e253b4743fcb000f85c835f0ac661eddd3",()=>b.logout,"00df1847c589fe202ee2a0068fbb346b6c41004891",()=>c.getRecentParticipants,"40c469aff0537f184c28e86574382e7b947c5966e0",0,l,"40d7fe121f91fa1d05e2be12c62d3438dead002b8a",0,k],66103)},86309,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0});var d={isRequestApiAllowedInCurrentPhase:function(){return k},throwForSearchParamsAccessInUseCache:function(){return j},throwWithStaticGenerationBailoutErrorWithDynamicError:function(){return i}};for(var e in d)Object.defineProperty(c,e,{enumerable:!0,get:d[e]});let f=a.r(60312),g=a.r(20635),h=a.r(24725);function i(a,b){throw Object.defineProperty(new f.StaticGenBailoutError(`Route ${a} with \`dynamic = "error"\` couldn't be rendered statically because it used ${b}. See more info here: https://nextjs.org/docs/app/building-your-application/rendering/static-and-dynamic#dynamic-rendering`),"__NEXT_ERROR_CODE",{value:"E543",enumerable:!1,configurable:!0})}function j(a,b){let c=Object.defineProperty(Error(`Route ${a.route} used \`searchParams\` inside "use cache". Accessing dynamic request data inside a cache scope is not supported. If you need some search params inside a cached function await \`searchParams\` outside of the cached function and pass only the required search params as arguments to the cached function. See more info here: https://nextjs.org/docs/messages/next-request-in-use-cache`),"__NEXT_ERROR_CODE",{value:"E842",enumerable:!1,configurable:!0});throw Error.captureStackTrace(c,b),a.invalidDynamicUsageError??=c,c}function k(a){switch(a.phase){case"action":case"render":return!0;case"after":{let a=g.actionAsyncStorage.getStore();if(a&&(a.isAppRoute||a.isAction))return!0;let b=h.afterTaskAsyncStorage.getStore();if(b)return"action"===b.rootTaskSpawnPhase;return!1}}}},51409,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"ReflectAdapter",{enumerable:!0,get:function(){return d}});class d{static get(a,b,c){let d=Reflect.get(a,b,c);return"function"==typeof d?d.bind(a):d}static set(a,b,c,d){return Reflect.set(a,b,c,d)}static has(a,b){return Reflect.has(a,b)}static deleteProperty(a,b){return Reflect.deleteProperty(a,b)}}},63681,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0});var d={RequestCookies:function(){return f.RequestCookies},ResponseCookies:function(){return f.ResponseCookies},stringifyCookie:function(){return f.stringifyCookie}};for(var e in d)Object.defineProperty(c,e,{enumerable:!0,get:d[e]});let f=a.r(36226)},16778,a=>{"use strict";var b=a.i(37936),c=a.i(9307),d=a.i(92435);async function e(){await (0,c.requireAdmin)();try{return{ok:!0,entries:await (0,d.listRecentParticipants)(20)}}catch(a){return console.error("Failed to load recent participants",a),{ok:!1}}}(0,a.i(13095).ensureServerEntryExports)([e]),(0,b.registerServerReference)(e,"00df1847c589fe202ee2a0068fbb346b6c41004891",null),a.s(["getRecentParticipants",0,e])},92435,a=>{"use strict";var b=a.i(61469);let c={SilverKite:"Silver Kite",SilverCoin:"Silver Coin",TryAgain:"Try Again",Pending:"Pending"};async function d(){return(await b.sql`
    SELECT id, name, code, status
    FROM campaigns
    WHERE status = 'Active'
    ORDER BY start_at DESC
    LIMIT 1
  `)[0]??null}async function e(a){let{status:c,prize:d,pageSize:e}=a,f=a.query.replace(/\D/g,""),g=(a.page-1)*e,[h]=await b.sql`
    WITH campaign AS (
      SELECT id FROM campaigns
      WHERE status = 'Active'
      ORDER BY start_at DESC
      LIMIT 1
    ),
    registry AS (
      SELECT
        i.id,
        i.imei,
        i.device_model,
        i.batch_code,
        CASE
          WHEN i.status = 'Blocked' THEN 'Blocked'
          WHEN s.outcome IN ('SilverKite', 'SilverCoin') THEN
            CASE s.verification_status
              WHEN 'Confirmed' THEN 'Claimed'
              WHEN 'Rejected' THEN 'Rejected'
              ELSE 'Winning Pending'
            END
          WHEN s.outcome = 'TryAgain' THEN 'Used'
          ELSE i.status::text
        END AS status,
        i.validation_attempts,
        i.source,
        i.assigned_prize,
        i.added_at,
        i.expected_retailer,
        p.full_name AS participant_name
      FROM imei_registry i
      JOIN campaign c ON c.id = i.campaign_id
      LEFT JOIN participants p
        ON p.campaign_id = i.campaign_id AND p.imei = i.imei
      LEFT JOIN scratch_results s ON s.participant_id = p.id
    ),
    filtered AS (
      SELECT * FROM registry
      WHERE (${c}::text IS NULL OR status = ${c}::text)
        AND (
          ${d}::text IS NULL
          OR (${d}::text = 'none' AND assigned_prize IS NULL)
          OR assigned_prize::text = ${d}::text
        )
        AND (${f}::text = '' OR imei LIKE '%' || ${f}::text || '%')
    ),
    paging AS (
      -- Clamp past-the-end pages to the last page that has rows.
      SELECT
        count(*)::int AS total,
        LEAST(
          ${g}::int,
          GREATEST((count(*)::int - 1) / ${e}::int, 0) * ${e}::int
        ) AS "offset"
      FROM filtered
    )
    SELECT
      (SELECT id FROM campaign) AS campaign_id,
      (SELECT count(*)::int FROM registry) AS total_all,
      paging.total,
      paging."offset",
      COALESCE(
        (
          SELECT json_agg(r ORDER BY r.added_at, r.imei)
          FROM (
            SELECT * FROM filtered
            ORDER BY added_at, imei
            LIMIT ${e}::int
            OFFSET (SELECT "offset" FROM paging)
          ) r
        ),
        '[]'
      ) AS rows
    FROM paging
  `;return{campaignId:h.campaign_id,total:h.total,totalAll:h.total_all,page:h.offset/e+1,pageSize:e,rows:h.rows.map(a=>({id:a.id,imei:a.imei,deviceModel:a.device_model??"",batch:a.batch_code??"",status:a.status,validationAttempts:a.validation_attempts,participantName:a.participant_name,addedAt:a.added_at,source:a.source,assignedPrize:a.assigned_prize,expectedRetailer:a.expected_retailer}))}}async function f(){let a=await d();if(!a)return null;let c=await b.sql`
    SELECT
      c.id,
      c.name,
      c.code,
      to_char(c.start_at, 'YYYY-MM-DD') AS "startAt",
      to_char(c.end_at, 'YYYY-MM-DD') AS "endAt",
      c.status,
      COALESCE(c.terms_url, '') AS "termsUrl",
      c.silver_coin_tiers AS "silverCoinTiers",
      c.silver_kite_per_week AS "silverKitePerWeek"
    FROM campaigns c
    WHERE c.id = ${a.id}
  `,[e]=await b.sql`
    WITH w AS (
      SELECT
        c.period_overrides,
        floor(extract(epoch FROM now() - c.start_at) / 604800)::int AS idx,
        c.start_at
          + floor(extract(epoch FROM now() - c.start_at) / 604800)
            * interval '7 days' AS ws
      FROM campaigns c
      WHERE c.id = ${a.id}
    ),
    k AS (
      SELECT
        *,
        ws + interval '7 days' AS we,
        to_char(ws AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS key
      FROM w
    )
    SELECT
      key,
      idx + 1 AS number,
      to_char(ws AT TIME ZONE 'Asia/Kathmandu', 'Dy, DD Mon YYYY, HH12:MI AM')
        AS "startLabel",
      to_char(we AT TIME ZONE 'Asia/Kathmandu', 'Dy, DD Mon YYYY, HH12:MI AM')
        AS "endLabel",
      period_overrides -> 'silverKiteDays' ->> key AS "selectedDay",
      (
        SELECT json_agg(
          json_build_object(
            'value', to_char(d, 'YYYY-MM-DD'),
            'label', to_char(d, 'Dy, DD Mon'),
            'unavailable',
              GREATEST(
                (d + interval '6 hours') AT TIME ZONE 'Asia/Kathmandu', ws, now()
              ) + interval '2 minutes'
                > LEAST((d + interval '22 hours') AT TIME ZONE 'Asia/Kathmandu', we)
          )
          ORDER BY d
        )
        FROM generate_series(
          (ws AT TIME ZONE 'Asia/Kathmandu')::date,
          ((we - interval '1 microsecond') AT TIME ZONE 'Asia/Kathmandu')::date,
          interval '1 day'
        ) d
      ) AS days
    FROM k
  `,f=await b.sql`
    SELECT kind, total, distributed
    FROM rewards
    WHERE campaign_id = ${a.id}
  `,g=f.find(a=>"SilverKite"===a.kind),h=f.find(a=>"SilverCoin"===a.kind);return{...c[0],silverKite:{total:g?.total??0,distributed:g?.distributed??0},silverCoin:{total:h?.total??0,distributed:h?.distributed??0},silverKiteWeek:e}}async function g(a){let{verification:d,scratch:e,pageSize:f}=a,g=a.query.trim().replace(/[\\%_]/g,"\\$&"),h=(a.page-1)*f,[i]=await b.sql`
    WITH campaign AS (
      SELECT id FROM campaigns
      WHERE status = 'Active'
      ORDER BY start_at DESC
      LIMIT 1
    ),
    entries AS (
      SELECT
        p.id,
        p.full_name AS name,
        p.mobile,
        p.imei,
        p.retailer_name AS retailer_entered,
        p.retailer_address,
        i.expected_retailer AS retailer_expected,
        s.id AS scratch_result_id,
        COALESCE(s.outcome, 'Pending') AS scratch,
        s.verification_status AS verification,
        p.participated_at
      FROM participants p
      JOIN campaign c ON c.id = p.campaign_id
      LEFT JOIN scratch_results s ON s.participant_id = p.id
      LEFT JOIN imei_registry i
        ON i.campaign_id = p.campaign_id AND i.imei = p.imei
    ),
    filtered AS (
      SELECT * FROM entries
      WHERE (
          ${d}::text IS NULL
          OR (${d}::text = 'none' AND verification IS NULL)
          OR verification::text = ${d}::text
        )
        AND (${e}::text IS NULL OR scratch::text = ${e}::text)
        AND (
          ${g}::text = ''
          OR name ILIKE '%' || ${g}::text || '%'
          OR mobile LIKE '%' || ${g}::text || '%'
          OR imei LIKE '%' || ${g}::text || '%'
          OR retailer_entered ILIKE '%' || ${g}::text || '%'
          OR retailer_address ILIKE '%' || ${g}::text || '%'
        )
    ),
    paging AS (
      -- Clamp past-the-end pages to the last page that has rows.
      SELECT
        count(*)::int AS total,
        LEAST(
          ${h}::int,
          GREATEST((count(*)::int - 1) / ${f}::int, 0) * ${f}::int
        ) AS "offset"
      FROM filtered
    )
    SELECT
      (SELECT id FROM campaign) AS campaign_id,
      (SELECT count(*)::int FROM entries) AS total_all,
      paging.total,
      paging."offset",
      COALESCE(
        (
          SELECT json_agg(r ORDER BY r.participated_at DESC, r.id)
          FROM (
            SELECT * FROM filtered
            ORDER BY participated_at DESC, id
            LIMIT ${f}::int
            OFFSET (SELECT "offset" FROM paging)
          ) r
        ),
        '[]'
      ) AS rows
    FROM paging
  `;return{campaignId:i.campaign_id,total:i.total,totalAll:i.total_all,page:i.offset/f+1,pageSize:f,rows:i.rows.map(a=>({id:a.id,name:a.name,mobile:a.mobile,imei:a.imei,retailerEntered:a.retailer_entered,retailerAddress:a.retailer_address,retailerExpected:a.retailer_expected,scratchResultId:a.scratch_result_id,scratch:c[a.scratch],verification:a.verification,participatedAt:a.participated_at}))}}async function h(a){return(await b.sql`
    SELECT
      p.id,
      p.full_name AS name,
      p.imei,
      p.retailer_name AS retailer,
      p.retailer_address,
      COALESCE(s.outcome, 'Pending') AS scratch,
      p.participated_at
    FROM participants p
    JOIN campaigns c ON c.id = p.campaign_id AND c.status = 'Active'
    LEFT JOIN scratch_results s ON s.participant_id = p.id
    ORDER BY p.participated_at DESC
    LIMIT ${a}
  `).map(a=>({id:a.id,name:a.name,imei:a.imei,retailer:a.retailer,retailerAddress:a.retailer_address,scratch:c[a.scratch],participatedAt:new Date(a.participated_at).toISOString()}))}async function i(a){let{group:c,pageSize:d}=a,e=(a.page-1)*d,[f]=await b.sql`
    WITH filtered AS (
      SELECT id, action, meta, created_at
      FROM audit_logs
      WHERE ${c}::text IS NULL OR action LIKE ${c}::text || '.%'
    ),
    paging AS (
      -- Clamp past-the-end pages to the last page that has rows.
      SELECT
        count(*)::int AS total,
        LEAST(
          ${e}::int,
          GREATEST((count(*)::int - 1) / ${d}::int, 0) * ${d}::int
        ) AS "offset"
      FROM filtered
    )
    SELECT
      (SELECT count(*)::int FROM audit_logs) AS total_all,
      paging.total,
      paging."offset",
      COALESCE(
        (
          SELECT json_agg(r ORDER BY r.created_at DESC, r.id)
          FROM (
            SELECT * FROM filtered
            ORDER BY created_at DESC, id
            LIMIT ${d}::int
            OFFSET (SELECT "offset" FROM paging)
          ) r
        ),
        '[]'
      ) AS rows
    FROM paging
  `;return{total:f.total,totalAll:f.total_all,page:f.offset/d+1,pageSize:d,rows:f.rows.map(a=>({id:a.id,action:a.action,summary:a.meta?.summary??a.action,ip:a.meta?.ip??null,createdAt:a.created_at}))}}async function j(){let[a]=await b.sql`
    WITH campaign AS (
      SELECT id, name, start_at, end_at, silver_coin_tiers, silver_kite_per_week
      FROM campaigns
      WHERE status = 'Active'
      ORDER BY start_at DESC
      LIMIT 1
    ),
    bounds AS (
      SELECT
        date_trunc('day', now() AT TIME ZONE 'Asia/Kathmandu')
          AT TIME ZONE 'Asia/Kathmandu' AS day_start,
        c.start_at
          + floor(extract(epoch FROM now() - c.start_at) / 604800)
            * interval '7 days' AS week_start
      FROM campaign c
    ),
    entries AS (
      SELECT p.participated_at, s.outcome, s.verification_status
      FROM participants p
      JOIN campaign c ON c.id = p.campaign_id
      LEFT JOIN scratch_results s ON s.participant_id = p.id
    ),
    stock AS (
      SELECT r.kind, r.total, r.distributed
      FROM rewards r
      JOIN campaign c ON c.id = r.campaign_id
    )
    SELECT
      (
        SELECT json_build_object(
          'name', name,
          'startAt', to_char(start_at AT TIME ZONE 'Asia/Kathmandu', 'YYYY-MM-DD'),
          'endAt', to_char(end_at AT TIME ZONE 'Asia/Kathmandu', 'YYYY-MM-DD')
        )
        FROM campaign
      ) AS campaign,
      (SELECT count(*)::int FROM entries) AS participants,
      (
        SELECT count(*)::int FROM entries, bounds
        WHERE participated_at >= day_start
      ) AS participants_today,
      (
        SELECT count(*)::int FROM entries
        WHERE verification_status = 'Pending'
      ) AS pending,
      (
        SELECT count(*)::int FROM entries
        WHERE verification_status = 'Confirmed'
      ) AS confirmed,
      (SELECT count(*)::int FROM entries WHERE outcome = 'TryAgain') AS try_again,
      (
        SELECT count(*)::int FROM entries, bounds
        WHERE outcome = 'SilverCoin' AND participated_at >= day_start
      ) AS coins_today,
      (
        SELECT count(*)::int FROM entries, bounds
        WHERE outcome = 'SilverKite' AND participated_at >= week_start
      ) AS kites_this_week,
      (SELECT total FROM stock WHERE kind = 'SilverKite') AS sk_total,
      (SELECT distributed FROM stock WHERE kind = 'SilverKite') AS sk_distributed,
      (SELECT total FROM stock WHERE kind = 'SilverCoin') AS sc_total,
      (SELECT distributed FROM stock WHERE kind = 'SilverCoin') AS sc_distributed,
      (SELECT silver_coin_tiers FROM campaign) AS silver_coin_tiers,
      (SELECT silver_kite_per_week FROM campaign) AS silver_kite_per_week
  `;return{campaign:a.campaign,participants:a.participants,participantsToday:a.participants_today,pending:a.pending,confirmed:a.confirmed,tryAgain:a.try_again,coinsToday:a.coins_today,kitesThisWeek:a.kites_this_week,silverKite:{total:a.sk_total??0,distributed:a.sk_distributed??0},silverCoin:{total:a.sc_total??0,distributed:a.sc_distributed??0},silverCoinTiers:a.silver_coin_tiers??[],silverKitePerWeek:a.silver_kite_per_week??0}}a.s(["AUDIT_LOG_GROUPS",0,["admin","imei","verification","settings"],"getActiveCampaign",0,d,"getCampaignSettings",0,f,"getOverviewStats",0,j,"listAuditLogsPage",0,i,"listImeisPage",0,e,"listParticipantsPage",0,g,"listRecentParticipants",0,h])}];

//# sourceMappingURL=_1izaq3w._.js.map